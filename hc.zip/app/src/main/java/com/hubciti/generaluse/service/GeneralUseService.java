package com.hubciti.generaluse.service;

import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

public interface GeneralUseService {

	public String temp();

	public String upload(MultipartFormDataInput input);

}
