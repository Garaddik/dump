/**
 * __wslib.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.webqa;

public interface __wslib extends javax.xml.rpc.Service {
    public java.lang.String get__wslibSoapAddress();

    public net.webqa.__wslibSoap get__wslibSoap() throws javax.xml.rpc.ServiceException;

    public net.webqa.__wslibSoap get__wslibSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
