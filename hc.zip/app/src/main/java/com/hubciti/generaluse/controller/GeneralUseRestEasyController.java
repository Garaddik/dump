package com.hubciti.generaluse.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

/**
 * The interface for GeneralUse
 * 
 * @author dhruvanath_mm
 */
@Path("/general")
public interface GeneralUseRestEasyController {

	/**
	 * Method for user login
	 * 
	 * @return
	 */
	@GET
	@Path("/temp")
	@Produces("text/xml")
	public String testResponse();
	
	
	@POST
	@Path("/upload")
	@Consumes("multipart/form-data")
	public String upload(MultipartFormDataInput input);
}
