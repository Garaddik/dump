package com.hubciti.generaluse.dao;

public interface GeneralUseDao {

	public String temp();
}
