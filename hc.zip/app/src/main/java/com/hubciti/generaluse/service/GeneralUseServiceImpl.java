package com.hubciti.generaluse.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hubciti.generaluse.dao.GeneralUseDao;

public class GeneralUseServiceImpl implements GeneralUseService {

	private static final Logger LOG = LoggerFactory
			.getLogger(GeneralUseServiceImpl.class);

	private GeneralUseDao generalUseDao;

	public void setGeneralUseDao(GeneralUseDao generalUseDao) {
		this.generalUseDao = generalUseDao;
	}

	public String temp() {
		String response;
		response = generalUseDao.temp();
		return response;
	}

	@Override
	public String upload(MultipartFormDataInput input) {

		Map<String, List<InputPart>> uploadForm = input.getFormDataMap();

		List<InputPart> inputParts = uploadForm.get("attachment");

		for (InputPart form : inputParts) {

			try {

				MultivaluedMap<String, String> header = form.getHeaders();
				String fileName = getFileName(header);

				InputStream inputStream = form.getBody(InputStream.class, null);

				byte[] bytes = IOUtils.toByteArray(inputStream);
				
				Random random = new Random();
				String ran = random.nextInt()+"";
				String name= ran + fileName;
				String filePath = "D://ProjectData//jboss-as-7.1.1.Final//standalone//deployments//ROOT.war//temp//"
						+ name;

				writeFile(bytes, filePath);
				return "file uploaded successfully : " + filePath;
 
			} catch (Exception exception) {

			}
		}

		return null;
	}

	private String getFileName(MultivaluedMap<String, String> header) {

		String[] contentDisposition = header.getFirst("Content-Disposition")
				.split(";");

		for (String filename : contentDisposition) {
			if ((filename.trim().startsWith("filename"))) {

				String[] name = filename.split("=");

				String finalFileName = name[1].trim().replaceAll("\"", "");
				return finalFileName;
			}
		}
		return "unknown";
	}

	private void writeFile(byte[] content, String filename) throws IOException {
		
		File file = new File(filename);
		if (!file.exists()) {
			System.out.println("not exist >> " + file.getAbsolutePath());
			file.createNewFile();
		}
		FileOutputStream fop = new FileOutputStream(file);
		fop.write(content);
		fop.flush();
		fop.close();
	}

}
