package admin.dao;

import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;





public class SpringSecurityDaoImpl extends JdbcDaoImpl {
	/**
	 * Getting the logger Instance.
	 */



}
